﻿#encoding=utf-8
from django.shortcuts import render
from django.http import HttpResponse
def say_hello(request):
   return HttpResponse("欢迎进入Django世界!")

def getA(request):
   return HttpResponse("Django是一个Python Web框架")
# Create your views here.
