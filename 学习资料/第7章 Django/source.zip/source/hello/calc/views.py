from django.shortcuts import render
from django.http import HttpResponse
def add(request,a,b):
   a=int(a)
   b=int(b)
   return HttpResponse(str(a+b))
def redu(request):
   a=int(request.GET['a'])
   b=int(request.GET['b'])
   return HttpResponse(str(a-b))
def muli(request):
   a=int(request.GET['a'])
   b=int(request.GET['b'])
   return HttpResponse(str(a*b))
def div(request):
   a=int(request.GET['a'])
   b=int(request.GET['b'])
   return HttpResponse(str(a/b))

# Create your views here.
