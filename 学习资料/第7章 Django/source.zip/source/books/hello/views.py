from django.shortcuts import render
from django.http import  HttpResponse
def index(request):
    return render(request, "from.html")
def login(request):
    return render(request, "login.html")
def main(request):
    return render(request, "main.html")

def person(request):
    #传递一个键值对(字典)的对象
    p1={"name":"czf","age":"30","address":"北京昌平"}
    hobby="readding"
    return render(request,'person.html',{"p":p1,"hobby":hobby})

def subject(request):
    subjectLists=["Python","redis","MongoDB","AI","Big_Data","H5",]
    a=[]
    score=[67,78,90,23,12,68,96,93]
    ss={"Python":"90","redis":"95","MongoDB":"80","AI":"100"}
    return render(request,"subject.html",{"subjects":subjectLists,"a":a,"score":score,"ss":ss})

def requestDemo(request):
    '''
    print(request.scheme)
    print(request.method)
    print(request.encoding)
    print(request.path)
    print(request.path_info)
    print(request.body)
    print(request.user)
    print(request.COOKIES['csrftoken'])
    print(request.session)
    print("&&&&&&&&")
    for t in request.META:
        print(t,":",request.META[t])
    '''
    print(request.get_host())
    print(request.is_ajax())
    print(request.is_secure())
    print(request.get_full_path())
    print(request.get_port())

    return render(request,"request.html")

def getAData(request):

    a=(int)(request.GET['a'])
    b=(int)(request.GET['b'])
    print(request.GET)
    print(a,b)
    return HttpResponse(str(a+b))

def login(request):
    print(request.POST)
    name=request.POST['username']
    pwd=request.POST['userpwd']
    print(name,pwd)
    if name=="admin" and pwd=="123456":
        return render(request,"main.html")
    else:
        return render(request,"from.html")